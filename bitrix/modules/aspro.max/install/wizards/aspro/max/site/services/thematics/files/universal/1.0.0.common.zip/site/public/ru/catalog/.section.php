<?
$sSectionName = "Каталог";
$arDirProperties = Array(
   "viewed_show" => "Y",
   "MENU_SHOW_SECTIONS" => "Y",
   "HIDE_LEFT_BLOCK" => "N"
);
?>