<?
$sSectionName = "Кнопки";
$arDirProperties = Array(

);
?>