<?
$sSectionName = "Партнеры";
$arDirProperties = Array(
   "HIDE_LEFT_BLOCK" => "Y"
);
?>