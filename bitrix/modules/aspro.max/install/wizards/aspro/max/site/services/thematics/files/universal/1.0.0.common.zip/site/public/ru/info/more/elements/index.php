<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Элементы");
?>
<div class="">
	<div class="tabs">
		<ul class="nav nav-tabs">
			<li class="box-shadow bordered active"><a href="#popularPosts" data-toggle="tab">Popular</a></li>
			<li class="box-shadow bordered"><a href="#recentPosts" data-toggle="tab">Recent</a></li>
		</ul>
	</div>
	<div class="tab-content">
		<div class="tab-pane active" id="popularPosts">
			Donec tellus massa, tristique sit amet condim vel, facilisis quis sapien. Praesent id enim sit amet odio vulputate eleifend in in tortor. Donec tellus massa, tristique sit amet condim vel, facilisis quis sapien. Praesent id enim sit amet odio vulputate eleifend in in tortor. Donec tellus massa, tristique sit amet condim vel, facilisis quis sapien. Praesent id enim sit amet odio vulputate eleifend in in tortor.
		</div>
		<div class="tab-pane" id="recentPosts">
			Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum
		</div>
	</div>
</div>
<hr class="long"/>

<div class="row">
	<div class="col-md-12">
		<h2>Accordion type 1</h2>					
		<div class="accordion-type-1">
			<div class="item-accordion-wrapper bordered box-shadow">
				<div class="accordion-head colored_theme_hover_bg-block accordion-close font_md" data-toggle="collapse" data-parent="#accordion1" href="#accordion1">
					<span class="arrow_open pull-right colored_theme_hover_bg-el"></span><span>Pricing Tables</span>
				</div>
				<div id="accordion1" class="panel-collapse collapse">
					<div class="accordion-body">
						<div class="row">
							<div class="col-md-12">
								Donec tellus massa, tristique sit amet condim vel, facilisis quis sapien. Praesent id enim sit amet odio vulputate eleifend in in tortor. Donec tellus massa, tristique sit amet condim vel, facilisis quis sapien. Praesent id enim sit amet odio vulputate eleifend in in tortor. Donec tellus massa, tristique sit amet condim vel, facilisis quis sapien. Praesent id enim sit amet odio vulputate eleifend in in tortor.
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="item-accordion-wrapper bordered box-shadow">
				<div class="accordion-head colored_theme_hover_bg-block accordion-close font_md" data-toggle="collapse" data-parent="#accordion2" href="#accordion2">
					<span class="arrow_open pull-right colored_theme_hover_bg-el"></span><span>Pricing Tables</span>
				</div>
				<div id="accordion2" class="panel-collapse collapse">
					<div class="accordion-body">
						Donec tellus massa, tristique sit amet condim vel, facilisis quis sapien. Praesent id enim sit amet odio vulputate eleifend in in tortor. Donec tellus massa, tristique sit amet condim vel, facilisis quis sapien. Praesent id enim sit amet odio vulputate eleifend in in tortor. Donec tellus massa, tristique sit amet condim vel, facilisis quis sapien. Praesent id enim sit amet odio vulputate eleifend in in tortor.
					</div>
				</div>
			</div>
			<div class="item-accordion-wrapper bordered box-shadow">
				<div class="accordion-head colored_theme_hover_bg-block accordion-close font_md" data-toggle="collapse" data-parent="#accordion3" href="#accordion3">
					<span class="arrow_open pull-right colored_theme_hover_bg-el"></span><span>Pricing Tables</span>
				</div>
				<div id="accordion3" class="panel-collapse collapse">
					<div class="accordion-body">
						Donec tellus massa, tristique sit amet condim vel, facilisis quis sapien. Praesent id enim sit amet odio vulputate eleifend in in tortor. Donec tellus massa, tristique sit amet condim vel, facilisis quis sapien. Praesent id enim sit amet odio vulputate eleifend in in tortor. Donec tellus massa, tristique sit amet condim vel, facilisis quis sapien. Praesent id enim sit amet odio vulputate eleifend in in tortor.
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<hr class="tall" />
<div class="row">	
	<div class="col-md-12">
		<h2>Accordion type 2</h2>
		<div class="accordion-type-2">
			<div class="item-accordion-wrapper bordered box-shadow">
				<div class="accordion-head colored_theme_hover_bg-block accordion-close font_md" data-toggle="collapse" data-parent="#accordion4" href="#accordion4">
					<span class="arrow_open pull-right colored_theme_hover_bg-el"></span><span>Pricing Tables</span>
				</div>
				<div id="accordion4" class="panel-collapse collapse">
					<div class="accordion-body">
						Donec tellus massa, tristique sit amet condim vel, facilisis quis sapien. Praesent id enim sit amet odio vulputate eleifend in in tortor. Donec tellus massa, tristique sit amet condim vel, facilisis quis sapien. Praesent id enim sit amet odio vulputate eleifend in in tortor. Donec tellus massa, tristique sit amet condim vel, facilisis quis sapien. Praesent id enim sit amet odio vulputate eleifend in in tortor.
					</div>
				</div>
			</div>
			<div class="item-accordion-wrapper bordered box-shadow">
				<div class="accordion-head colored_theme_hover_bg-block accordion-close font_md" data-toggle="collapse" data-parent="#accordion5" href="#accordion5">
					<span class="arrow_open pull-right colored_theme_hover_bg-el"></span><span>Pricing Tables</span>
				</div>
				<div id="accordion5" class="panel-collapse collapse">
					<div class="accordion-body">
						Donec tellus massa, tristique sit amet condim vel, facilisis quis sapien. Praesent id enim sit amet odio vulputate eleifend in in tortor. Donec tellus massa, tristique sit amet condim vel, facilisis quis sapien. Praesent id enim sit amet odio vulputate eleifend in in tortor. Donec tellus massa, tristique sit amet condim vel, facilisis quis sapien. Praesent id enim sit amet odio vulputate eleifend in in tortor.
					</div>
				</div>
			</div>
			<div class="item-accordion-wrapper bordered box-shadow">
				<div class="accordion-head colored_theme_hover_bg-block accordion-close font_md" data-toggle="collapse" data-parent="#accordion6" href="#accordion6">
					<span class="arrow_open pull-right colored_theme_hover_bg-el"></span><span>Pricing Tables</span>
				</div>
				<div id="accordion6" class="panel-collapse collapse">
					<div class="accordion-body">
						Donec tellus massa, tristique sit amet condim vel, facilisis quis sapien. Praesent id enim sit amet odio vulputate eleifend in in tortor. Donec tellus massa, tristique sit amet condim vel, facilisis quis sapien. Praesent id enim sit amet odio vulputate eleifend in in tortor. Donec tellus massa, tristique sit amet condim vel, facilisis quis sapien. Praesent id enim sit amet odio vulputate eleifend in in tortor.
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<hr class="tall" />
<div class="row">
	<div class="col-md-6">
		<h2>Toggle</h2>
		<div class="toogle">
			<section class="toggle active">
				<label>Curabitur eget leo at velit imperdiet vague iaculis vitaes?</label>
				<div class="toggle-content">
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur pellentesque neque eget diam posuere porta. Quisque ut nulla at nunc <a href="#">vehicula</a> lacinia. Proin adipiscing porta tellus, ut feugiat nibh adipiscing sit amet.</p>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur pellentesque neque eget diam posuere porta. Quisque ut nulla at nunc <a href="#">vehicula</a> lacinia. Proin adipiscing porta tellus, ut feugiat nibh adipiscing sit amet. In eu justo a felis faucibus ornare vel id metus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; </p>
				</div>
			</section>
			<section class="toggle">
				<label>Curabitur eget leo at imperdiet vague iaculis vitaes?</label>
				<div class="toggle-content">
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur eget leo at velit imperdiet varius. In eu ipsum vitae velit congue iaculis vitae at risus. Nullam tortor nunc, bibendum vitae semper a, volutpat eget massa. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer fringilla, orci sit amet posuere auctor, orci eros pellentesque odio, nec pellentesque erat ligula nec massa. Aenean consequat lorem ut felis ullamcorper posuere gravida tellus faucibus. Maecenas dolor elit, pulvinar eu vehicula eu, consequat et lacus. Duis et purus ipsum. In auctor mattis ipsum id molestie. Donec risus nulla, fringilla a rhoncus vitae, semper a massa. Vivamus ullamcorper, enim sit amet consequat laoreet, tortor tortor dictum urna, ut egestas urna ipsum nec libero. Nulla justo leo, molestie vel tempor nec, egestas at massa. Aenean pulvinar, felis porttitor iaculis pulvinar, odio orci sodales odio, ac pulvinar felis quam sit.</p>
				</div>
			</section>
			<section class="toggle">
				<label>Curabitur eget leo at velit imperdiet vague iaculis vitaes?</label>
				<div class="toggle-content">
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur eget leo at velit imperdiet varius. In eu ipsum vitae velit congue iaculis vitae at risus. Nullam tortor nunc, bibendum vitae semper a, volutpat eget massa. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer fringilla, orci sit amet posuere auctor, orci eros pellentesque odio, nec pellentesque erat ligula nec massa. Aenean consequat lorem ut felis ullamcorper posuere gravida tellus faucibus. Maecenas dolor elit, pulvinar eu vehicula eu, consequat et lacus. Duis et purus ipsum. In auctor mattis ipsum id molestie. Donec risus nulla, fringilla a rhoncus vitae, semper a massa. Vivamus ullamcorper, enim sit amet consequat laoreet, tortor tortor dictum urna, ut egestas urna ipsum nec libero. Nulla justo leo, molestie vel tempor nec, egestas at massa. Aenean pulvinar, felis porttitor iaculis pulvinar, odio orci sodales odio, ac pulvinar felis quam sit.</p>
				</div>
			</section>
		</div>
	</div>
	<div class="col-md-6">
		<h2>One Toggle Open At A Time</h2>
		<div class="toogle toogle-accordion">
			<section class="toggle active">
				<label>Curabitur eget leo at velit imperdiet vague iaculis vitaes?</label>
				<div class="toggle-content">
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur pellentesque neque eget diam posuere porta. Quisque ut nulla at nunc <a href="#">vehicula</a> lacinia. Proin adipiscing porta tellus, ut feugiat nibh adipiscing sit amet. In eu justo a felis faucibus ornare vel id metus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In eu libero ligula. Fusce eget metus lorem, ac viverra leo. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur pellentesque neque eget diam posuere porta. Quisque ut nulla at nunc <a href="#">vehicula</a> lacinia. Proin adipiscing porta tellus, ut feugiat nibh adipiscing sit amet. In eu justo a felis faucibus ornare vel id metus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In eu libero ligula. Fusce eget metus lorem, ac viverra leo. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur pellentesque neque eget diam posuere porta. Quisque ut nulla at nunc <a href="#">vehicula</a> lacinia. Proin adipiscing porta tellus, ut feugiat nibh adipiscing sit amet. In eu justo a felis faucibus ornare vel id metus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In eu libero ligula. Fusce eget metus lorem, ac viverra leo. </p>
				</div>
			</section>
			<section class="toggle">
				<label>Curabitur eget leo at velit imperdiet vague iaculis vitaes?</label>
				<div class="toggle-content">
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur eget leo at velit imperdiet varius. In eu ipsum vitae velit congue iaculis vitae at risus. Nullam tortor nunc, bibendum vitae semper a, volutpat eget massa. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer fringilla, orci sit amet posuere auctor, orci eros pellentesque odio, nec pellentesque erat ligula nec massa. Aenean consequat lorem ut felis ullamcorper posuere gravida tellus faucibus. Maecenas dolor elit, pulvinar eu vehicula eu, consequat et lacus. Duis et purus ipsum. In auctor mattis ipsum id molestie. Donec risus nulla, fringilla a rhoncus vitae, semper a massa. Vivamus ullamcorper, enim sit amet consequat laoreet, tortor tortor dictum urna, ut egestas urna ipsum nec libero. Nulla justo leo, molestie vel tempor nec, egestas at massa. Aenean pulvinar, felis porttitor iaculis pulvinar, odio orci sodales odio, ac pulvinar felis quam sit.</p>
				</div>
			</section>
			<section class="toggle">
				<label>Curabitur eget leo at velit imperdiet vague iaculis vitaes?</label>
				<div class="toggle-content">
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur eget leo at velit imperdiet varius. In eu ipsum vitae velit congue iaculis vitae at risus. Nullam tortor nunc, bibendum vitae semper a, volutpat eget massa. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer fringilla, orci sit amet posuere auctor, orci eros pellentesque odio, nec pellentesque erat ligula nec massa. Aenean consequat lorem ut felis ullamcorper posuere gravida tellus faucibus. Maecenas dolor elit, pulvinar eu vehicula eu, consequat et lacus. Duis et purus ipsum. In auctor mattis ipsum id molestie. Donec risus nulla, fringilla a rhoncus vitae, semper a massa. Vivamus ullamcorper, enim sit amet consequat laoreet, tortor tortor dictum urna, ut egestas urna ipsum nec libero. Nulla justo leo, molestie vel tempor nec, egestas at massa. Aenean pulvinar, felis porttitor iaculis pulvinar, odio orci sodales odio, ac pulvinar felis quam sit.</p>
				</div>
			</section>
		</div>
	</div>
</div>
<hr class="long"/>
<h2></h2>
<div class="form inline FEEDBACK">
	<!--noindex-->
		<div class="form_head"><h4>Форма в 2 ряда</h4></div>
		<form name="FEEDBACK" action="<?=$APPLICATION->GetCurPage()?>" method="POST" enctype="multipart/form-data" novalidate="novalidate">
			<div class="form_body">
				<div class="form_left">
					<div class="form-control">
						<label><span>Сообщение&nbsp;<span class="star">*</span></span></label>
										<textarea data-sid="POST" required="" name="form_textarea_14" cols="40" rows="5" left=""></textarea>			</div>
																					</div>
						<div class="form_right">
																											<div class="form-control">
						<label><span>Ваше имя&nbsp;<span class="star">*</span></span></label>
										<input type="text" class="inputtext" data-sid="CLIENT_NAME" required="" name="form_text_11" value="" size="0">			</div>
																																					<div class="form-control">
						<label><span>Контактный телефон&nbsp;<span class="star">*</span></span></label>
										<input type="text" class="phone" data-sid="PHONE" required="" name="form_text_12" value="" size="0">			</div>
																																					<div class="form-control">
						<label><span>E-mail</span></label>
										<input type="email" placeholder="mail@domen.com" class="inputtext" data-sid="EMAIL" name="form_email_13" value="" size="0">			</div>
						</div>
						
						<div class="clearboth"></div>
			</div>
			<div class="form_footer">
				<button type="submit" class="btn btn-default" value="submit" name="web_form_submit"><span>Отправить</span></button>
				<button type="reset" class="btn btn-default white" value="reset" name="web_form_reset"><span>Отменить</span></button>
				
			</div>
		</form>
	<!--/noindex-->
</div>
<hr class="long" />
<div class="form inline FEEDBACK">
	<!--noindex-->
		<div class="form_head"><h4>Форма в ряд</h4></div>
		<form name="FEEDBACK" action="<?=$APPLICATION->GetCurPage()?>" method="POST" enctype="multipart/form-data" novalidate="novalidate">
			<div class="form_body">
				<div class="form-control">
					<label><span>Сообщение&nbsp;<span class="star">*</span></span></label>
					<textarea data-sid="POST" required="" name="form_textarea_14" cols="40" rows="5" left=""></textarea>
				</div>
				<div class="form-control">
					<label><span>Ваше имя&nbsp;<span class="star">*</span></span></label>
					<input type="text" class="inputtext" data-sid="CLIENT_NAME" required="" name="form_text_11" value="" size="0">
				</div>
				<div class="form-control">
					<label><span>Контактный телефон&nbsp;<span class="star">*</span></span></label>
					<input type="text" class="phone" data-sid="PHONE" required="" name="form_text_12" value="" size="0">			
				</div>
																																				<div class="form-control">
				<label><span>E-mail</span></label>
				<input type="email" placeholder="mail@domen.com" class="inputtext" data-sid="EMAIL" name="form_email_13" value="" size="0">			</div>

				
				<div class="clearboth"></div>
			</div>
			<div class="form_footer">
				<button type="submit" class="btn btn-default" value="submit" name="web_form_submit"><span>Отправить</span></button>
				<button type="reset" class="btn btn-default white" value="reset" name="web_form_reset"><span>Отменить</span></button>
				
			</div>
		</form>
	<!--/noindex-->
</div>
<hr class="long" />
<div class="bottom_nav block">
	<div class="module-pagination">
		<ul class="flex-direction-nav">
			<li class="flex-nav-prev  disabled"><a href="<?=$APPLICATION->GetCurPage()?>" class="flex-prev"></a></li>
			<li class="flex-nav-next "><a href="<?=$APPLICATION->GetCurPage()?>" class="flex-next"></a></li>
		</ul>
		<span class="nums">
			<span class="cur">1</span>
			<a href="<?=$APPLICATION->GetCurPage()?>">2</a>
			<a href="<?=$APPLICATION->GetCurPage()?>">3</a>
			<span class="point_sep"></span>
			<a href="<?=$APPLICATION->GetCurPage()?>">26</a>
		</span>
	</div>
</div>
<div class="clearfix"></div>
<hr class="long" />
<div class="row">
	<div class="col-md-12">
		<h2>Labels</h2>
		<span class="label label-default">Default</span>
		<span class="label label-primary">Primary</span>
		<span class="label label-success">Success</span>
		<span class="label label-info">Info</span>
		<span class="label label-warning">Warning</span>
		<span class="label label-danger">Danger</span>
		<h2 class="spaced">Tooltips</h2>
		<p>Tight pants next level keffiyeh <a rel="tooltip" href="#" data-original-title="Default tooltip">you probably</a> haven't heard of them. Photo booth beard raw denim letterpress vegan messenger bag stumptown. Farm-to-table seitan, mcsweeney's fixie sustainable quinoa 8-bit american apparel <a title="Another tooltip" rel="tooltip" href="#">have a</a> terry richardson vinyl chambray. </p>
	</div>
</div>
<hr class="long" />
<div class="row"> 						 
	<div class="col-md-12">							 
		<h4>Оформление блока</h4>  
		<div class="styled-block">Красивый блок на сайте</div>
	</div>
	<div class="col-md-12">

		<table class="order-block bordered">
			<tbody>
				<tr>
					<td class="col-md-9 col-sm-8 col-xs-7 valign">
						<div class="block-item">
							<div class="flexbox flexbox--row">
								<div class="block-item__image icon_sendmessage"><?=CMax::showIconSvg("sendmessage", SITE_TEMPLATE_PATH."/images/svg/sendmessage.svg", "", "colored_theme_svg", true, false);?></div>
								<div class="text darken">
									Произвольный текст.<br />Красивее в две строки.
								</div>
							</div>
						</div>
					</td>
					<td class="col-md-3 col-sm-4 col-xs-5 valign btns-col">
						<div class="btns">
							<span>
								<span class="btn btn-default animate-load" data-event="jqm" data-param-form_id="ASK" data-name="example" data-autoload-STRING="Автозаполнение строки">Пример формы</span>
							</span>
						</div>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
	<div class="col-md-12">
		<blockquote class="info">Text</blockquote>
	</div>
</div>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>