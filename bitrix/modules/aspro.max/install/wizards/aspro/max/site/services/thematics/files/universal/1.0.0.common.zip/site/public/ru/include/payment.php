<img src="#SITE_DIR#include/mastercard.png" alt="MasterCard" title="MasterCard" />
<img src="#SITE_DIR#include/visa.png" alt="visa" title="visa" />
<img src="#SITE_DIR#include/yandex.png" alt="Yandex Money" title="Yandex Money" />
<img src="#SITE_DIR#include/webmoney.png" alt="Webmoney" title="Webmoney" />
<img src="#SITE_DIR#include/qiwi.png" alt="qiwi" title="qiwi" />