<?
$aMenuLinks = Array(
	Array(
		"Каталог", 
		"#SITE_DIR#catalog/", 
		Array(), 
		Array("CLASS"=>"catalog wide_menu", "ICON"=> "icon_catalog"), 
		"" 
	)
);
?>