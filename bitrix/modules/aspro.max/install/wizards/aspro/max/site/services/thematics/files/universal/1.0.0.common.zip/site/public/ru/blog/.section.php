<?
$sSectionName = "Блог";
$arDirProperties = Array(
   "HIDE_LEFT_BLOCK" => "N"
);
?>