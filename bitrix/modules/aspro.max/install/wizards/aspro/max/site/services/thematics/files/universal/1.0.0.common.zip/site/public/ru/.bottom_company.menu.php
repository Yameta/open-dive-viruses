<?
$aMenuLinks = Array(
	Array(
		"Компания", 
		"#SITE_DIR#company/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>