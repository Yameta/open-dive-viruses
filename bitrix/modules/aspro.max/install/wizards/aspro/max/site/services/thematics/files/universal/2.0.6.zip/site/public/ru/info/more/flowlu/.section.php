<?
$sSectionName = "Flowlu";
$arDirProperties = Array(
   "description" => "Explore an all-in-one business management solution for task and project tracking, accounting, CRM, sales automation, and other tools for teams of all sizes.",
   "keywords" => "business management software, all-in-one software, small business software, business management solutions, business management software for small business, cloud business management software, free business management software, online project management, invoicing software, task tracking tool, accounting software",
   "title" => "All-In-One Software for Project Management"
);
?>