<?global $APPLICATION, $arRegion, $arSite, $arTheme, $bIndexBot, $is404, $isForm, $isIndex;?>

<div class="bx_areas">
	<?CMax::ShowPageType('bottom_counter');?>
</div>
<?CMax::ShowPageType('search_title_component');?>
<?CMax::setFooterTitle();
CMax::showFooterBasket();?>
<script>
	if (typeof updateBottomIconsPanel === 'function') {
		var counter = 0;
		var arItemsCompare = [];
		for(var key in arBasketAspro["COMPARE"]){
			if(arBasketAspro["COMPARE"].hasOwnProperty(key)) {
				arItemsCompare[counter] = arBasketAspro["COMPARE"][key];
				counter++;
			}
		}

		updateBottomIconsPanel({
			"COMPARE":{
				"COUNT": arItemsCompare.length,
			}
		});
	}
</script>
<div id="popup_iframe_wrapper"></div>
<?include_once('bottom_footer_custom.php');?>