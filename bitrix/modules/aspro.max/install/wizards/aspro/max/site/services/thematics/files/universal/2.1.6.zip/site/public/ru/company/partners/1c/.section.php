<?
$sSectionName = "Интеграция сайта с 1С";
$arDirProperties = Array(
   "description" => "Рассказываем о преимуществах интеграции сайта с системой учета 1С"
);
?>