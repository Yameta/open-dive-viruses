<?
$sSectionName = "Условия доставки";
$arDirProperties = Array(

);
?>