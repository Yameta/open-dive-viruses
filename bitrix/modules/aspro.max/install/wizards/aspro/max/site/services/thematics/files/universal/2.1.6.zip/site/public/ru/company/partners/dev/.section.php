<?
$sSectionName = "Разработка сайтов";
$arDirProperties = Array(
   "description" => "Рассказываем о преимуществах запуска проекта на готовом решении Аспро"
);
?>