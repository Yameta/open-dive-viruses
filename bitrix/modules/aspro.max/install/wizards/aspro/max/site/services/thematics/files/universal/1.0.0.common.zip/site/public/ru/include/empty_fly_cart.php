<div class="title">Ваша корзина пуста</div>
 
<p>Исправить это просто: выберите в каталоге интересующий <br>товар и нажмите кнопку &laquo;В корзину&raquo;. </p>

<a class="btn btn-default round-ignore btn-lg" href="<?=CMax::GetFrontParametrValue("CATALOG_PAGE_URL");?>"><span>Перейти в каталог</span></a>