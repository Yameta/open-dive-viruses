<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");
$APPLICATION->SetTitle("");?><?
global $USER;

if($_GET["auth_service_error"]){
	LocalRedirect(SITE_DIR.'personal/');
}
if(!$USER->IsAuthorized()){?> <?if(isset($_REQUEST['backurl']) && $_REQUEST['backurl']) // fix ajax url
	{
		if($_REQUEST['backurl'] != $_SERVER['REQUEST_URI'])
		{
			$_SERVER['QUERY_STRING'] = '';
			$_SERVER['REQUEST_URI'] = $_REQUEST['backurl'];
			$APPLICATION->reinitPath();
		}
	}?> <a href="#" class="close jqmClose"><?=CMax::showIconSvg('', SITE_TEMPLATE_PATH.'/images/svg/Close.svg')?></a>
<div id="wrap_ajax_auth" class="form">
	<div class="form_head">
		<h2><?=\Bitrix\Main\Localization\Loc::getMessage('AUTHORIZE_TITLE');?></h2>
	</div>
	 <?$APPLICATION->IncludeComponent(
	"bitrix:system.auth.form",
	"main",
	Array(
		"AJAX_MODE" => "N",
		"AUTH_URL" => SITE_DIR."auth/",
		"BACKURL" => ((isset($_REQUEST['backurl'])&&$_REQUEST['backurl'])?$_REQUEST['backurl']:""),
		"FORGOT_PASSWORD_URL" => SITE_DIR."auth/forgot-password/?forgot-password=yes",
		"POPUP_AUTH" => "Y",
		"PROFILE_URL" => SITE_DIR."auth/",
		"REGISTER_URL" => SITE_DIR."auth/registration/?register=yes",
		"SHOW_ERRORS" => "Y"
	)
);?>
</div>
<?}
elseif(strlen($_REQUEST['backurl'])){
	LocalRedirect($_REQUEST['backurl']);
}
else{
	if(strpos($_SERVER['HTTP_REFERER'], SITE_DIR.'personal/') === false && strpos($_SERVER['HTTP_REFERER'], SITE_DIR.'ajax/form.php') === false){
		$APPLICATION->ShowHead();
		?>
		<script>
			jsAjaxUtil.ShowLocalWaitWindow( 'id', 'wrap_ajax_auth', true );
			BX.reload(false)
		</script>
		<?
	}
	else{
		LocalRedirect(SITE_DIR.'personal/');
	}
}