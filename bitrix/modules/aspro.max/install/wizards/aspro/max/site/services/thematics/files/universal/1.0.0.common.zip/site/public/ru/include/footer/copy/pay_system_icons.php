<i title="Cash" class="cacsh"></i>
<i title="MasterCard" class="mastercard"></i>
<i title="Visa" class="visa"></i>
<i title="Yandex" class="yandex_money"></i>
<i title="WebMoney" class="webmoney"></i>
<i title="Qiwi" class="qiwi"></i>
<i title="Sberbank" class="sbrf"></i>
<i title="Alfa" class="alfa"></i>