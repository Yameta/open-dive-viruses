<?
$sSectionName = "Элементы";
$arDirProperties = Array(

);
?>