<?
$sSectionName = "Сайты по тематикам";
$arDirProperties = Array(
   "description" => "Рассказываем о плюсах готовых тематик Аспро для быстрого запуска сайта"
);
?>