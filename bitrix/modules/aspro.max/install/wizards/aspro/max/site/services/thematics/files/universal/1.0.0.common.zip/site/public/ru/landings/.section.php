<?
$sSectionName = "Обзоры";
$arDirProperties = Array(
   "title" => "Обзоры",
   "HIDE_LEFT_BLOCK" => "N",
   "HIDE_LEFT_BLOCK_DETAIL" => "Y"
);
?>