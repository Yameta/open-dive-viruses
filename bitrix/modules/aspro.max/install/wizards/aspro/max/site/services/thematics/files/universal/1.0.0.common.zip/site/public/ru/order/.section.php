<?
$sSectionName = "Оформление заказа";
$arDirProperties = Array(
	"HIDE_LEFT_BLOCK" => "Y"
);
?>