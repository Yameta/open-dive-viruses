<?
$aMenuLinks = Array(
	Array(
		"Помощь", 
		"#SITE_DIR#help/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Условия оплаты", 
		"#SITE_DIR#help/payment/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Условия доставки", 
		"#SITE_DIR#help/delivery/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Гарантия на товар", 
		"#SITE_DIR#help/warranty/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Вопрос-ответ", 
		"#SITE_DIR#info/faq/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Обзоры", 
		"#SITE_DIR#landings/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>