<?
$sSectionName = "Корзина";
$arDirProperties = Array(
	"HIDE_LEFT_BLOCK" => "Y"
);
?>