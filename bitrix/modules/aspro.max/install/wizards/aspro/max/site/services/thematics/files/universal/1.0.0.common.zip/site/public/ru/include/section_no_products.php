<span class="big_text font_exlg">К сожалению, раздел пуст</span><br>
 <span class="middle_text font_sm muted777">В данный момент нет активных товаров</span>