<div class="required-fields-note">
    <span class="star">*</span><span class="muted888 font_xs"> &ndash; обязательные поля</span>
</div>