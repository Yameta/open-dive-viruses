<?
$sSectionName = "Отзывы";
$arDirProperties = Array(
   "HIDE_LEFT_BLOCK" => "N"
);
?>