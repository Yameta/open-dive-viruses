<?
if(!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true ) die();

/**
 * array from \Aspro\Functions\CAsproMax::showBlockHtml
 * 
 * @var array $arOptions = [
 *  'CONFIG' => array,
 *  'ITEMS' => array,
 *  'DATA_BREAKPOINTS' => string,
 *  'DATA_ITEMS' => json
 * ]
 */
$arOptions = $arConfig['PARAMS'];

?>
<div class="small-gallery-block"
    data-additional_items='<?=$arOptions['DATA_ITEMS'];?>'
    <?=(!$arOptions['CONFIG']['IS_ACTIVE'] ? ' style="display:none;"' : '');?>
>
    <div class="row flexbox flexbox--row">
        <?foreach ($arOptions['ITEMS'] as $key => $arPhoto):?>
            <div class="small-gallery-block__item col-md-3 col-sm-4 col-xs-6<?=$arPhoto['visibility_class'] ?? '';?>">
                <a href="<?=$arPhoto['src'];?>" class="small-gallery-block__item-image fancy-plus" target="_blank" title="<?=$arPhoto['title'];?>">
                    <img class="lazy img-responsive inline"
                        data-src="<?=$arPhoto['thumb'];?>" 
                        src="<?=$arPhoto['stub'];?>"  
                        title="<?=$arPhoto['title'];?>" alt="<?=$arPhoto['alt'];?>" 
                    >
                </a>
            </div>
        <?endforeach;?>

        <div class="small-gallery-block__item-counter col-md-3 col-sm-4 col-xs-6"<?=$arOptions['DATA_BREAKPOINTS'];?>></div>
    </div>
</div>