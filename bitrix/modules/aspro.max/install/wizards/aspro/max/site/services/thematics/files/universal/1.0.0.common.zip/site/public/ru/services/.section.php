<?
$sSectionName = "Услуги";
$arDirProperties = Array(
   "HIDE_LEFT_BLOCK" => "N",
   "MENU_SHOW_SECTIONS" => "Y",
   "MENU_SHOW_ELEMENTS" => "Y",
   "MENU" => "Y"
);
?>