<?
$aMenuLinks = Array(
	Array(
		"Акции", 
		"#SITE_DIR#sale/", 
		Array(), 
		Array("CLASS" => "icon sale_icon", "ICON"=> "icon_discount"), 
		"" 
	)
);
?>