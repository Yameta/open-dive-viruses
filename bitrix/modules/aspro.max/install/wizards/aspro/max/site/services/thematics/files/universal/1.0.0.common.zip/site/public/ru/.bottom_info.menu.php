<?
$aMenuLinks = Array(
	Array(
		"Информация", 
		"#SITE_DIR#info/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>