<?
$sSectionName = "Магазины";
$arDirProperties = Array(

);
?>