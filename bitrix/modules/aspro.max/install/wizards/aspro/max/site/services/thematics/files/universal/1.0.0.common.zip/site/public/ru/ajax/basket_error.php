<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");?>
<?\Bitrix\Main\Loader::includeModule('aspro.max');?>
<a href="#" class="close jqmClose"><?=CMax::showIconSvg('', SITE_TEMPLATE_PATH.'/images/svg/Close.svg')?></a>
<div class="popup-intro">
	<div class="pop-up-title">Ошибка корзины</div>
</div>
<div class="form-wr">
	<div class="ajax_text" id="bx_ajax_text"></div>
</div>
