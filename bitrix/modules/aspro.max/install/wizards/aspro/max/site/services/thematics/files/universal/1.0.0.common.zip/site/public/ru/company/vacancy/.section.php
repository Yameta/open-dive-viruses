<?
$sSectionName = "Вакансии";
$arDirProperties = Array(
   "HIDE_LEFT_BLOCK" => "N",
   "HIDE_LEFT_BLOCK_DETAIL" => "N",
   "HIDE_LEFT_BLOCK_LIST" => "N"
);
?>