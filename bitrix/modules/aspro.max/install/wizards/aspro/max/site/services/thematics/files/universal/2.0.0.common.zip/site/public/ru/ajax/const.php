<?
if(!defined('PUBLIC_VENDOR_MODULE_ID')){
	define('PUBLIC_VENDOR_MODULE_ID', 'aspro.max');
}

if(!defined('STATISTIC_SKIP_ACTIVITY_CHECK')){
	define('STATISTIC_SKIP_ACTIVITY_CHECK', true);
}

if(!defined('NO_KEEP_STATISTIC')){
	define('NO_KEEP_STATISTIC', true);
}

if(!defined('STOP_STATISTICS')){
	define('STOP_STATISTICS', true);
}

if(!defined('NO_AGENT_STATISTIC')){
	define('NO_AGENT_STATISTIC', true);
}

if(!defined('NO_AGENT_CHECK')){
	define('NO_AGENT_CHECK', true);
}

if(!defined('PUBLIC_AJAX_MODE')){
	define('PUBLIC_AJAX_MODE', true);
}
