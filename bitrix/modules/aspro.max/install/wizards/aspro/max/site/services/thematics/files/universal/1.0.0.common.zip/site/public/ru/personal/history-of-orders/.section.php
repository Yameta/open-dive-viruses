<?
$sSectionName = "История заказов";
$arDirProperties = Array(
   "lmenu" => "да"
);
?>