<span class="big_text">К сожалению, ничего не найдено</span><br>
 <span class="middle_text">Ни один товар не удовлетворяет заданным параметрам фильтра</span>