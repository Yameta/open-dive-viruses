<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetTitle("Flowlu.Link - mobile website builder");
$APPLICATION->SetPageProperty("description","Share information through your Instagram link in bio");
$APPLICATION->SetPageProperty("keywords","link in bio, link in bio instagram, bio link, link in bio tool, instagram bio link, free bio link, biolink");
?><p style="text-align: center;">
 <img alt="Link in bio tool" title ="Flowlu.Link for Instagram" src="#SITE_DIR#info/more/img/flowlulink.jpg" class="img-responsive rounded-4">
</p>
<p>
Flowlu.Link is <a href="https://flowlu.link" title="mobile website builder" target="_blank">mobile website builder</a>. This is a new approach to information sharing through link in bio. As you’ve attached a bio link, you can set up a fully customizable portal for your clients to reach the information. 
Since Instagram bio link is essential for any business, Flowlu.Link will provide you with a well-designed link in bio tool that suits any industry. 
</p>
<p>
Add links to any social media and contacts, because only you choose the way of communication. On Flowlu.Link, the powerful link in bio for Instagram, you can share some follow-up information about your business, because we know how important it is to support your business with a good-looking and user-friendly solution.
</p>
<p>
Let your clients choose the most convenient way of contacting your business through biolink. Since it can function as a free bio link tool, it’ll help you to achieve more profit with little cost.
</p>
<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>