<?$APPLICATION->IncludeComponent(
    "aspro:developer.max",
    ".default",
    array(
        "CACHE_TYPE" => "A",
        "CACHE_TIME" => "3600000",
        "CACHE_GROUPS" => "N",
        "COMPONENT_TEMPLATE" => ".default",
        "COLOR" => $color,
    ),
    false
);?>