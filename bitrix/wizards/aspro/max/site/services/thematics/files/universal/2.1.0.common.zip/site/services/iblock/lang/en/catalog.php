<?php
$MESS["UF_FILTER_VIEW"] = "SmartFilter view";
$MESS["UF_POPULAR"] = "Popular category";
$MESS["UF_SECTION_DESCR"] = "Description of the section for SEO";
$MESS["UF_SECTION_TEMPLATE"] = "Default Product List Template";
$MESS["WIZ_DISCOUNT"] = "Demo discount for a hit, novelty, advise, promotion";
$MESS["WIZ_PRECET"] = "Special Items";
$MESS["WIZ_PRICE_NAME"] = "Retail price";
