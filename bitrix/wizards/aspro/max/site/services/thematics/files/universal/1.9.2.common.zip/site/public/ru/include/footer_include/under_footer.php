<?include_once('under_footer_custom.php');?>

<?global $USER;
if($_SESSION['ASPRO_MAX_SUCCESSFUL_AUTHORIZATION'] == 'Y'){
    if($USER->GetLogin()){
        $userName = $USER->GetLogin();
    }elseif($USER->GetFirstName() || $USER->GetLastName()){
        $userName = $USER->GetFirstName() ." ".$USER->GetLastName();
    }
    if($userName){
        \Aspro\Functions\CAsproMax::noticeSuccessfulAuthorization($userName);
    }
}