<?
$MESS["WZD_OPTION_0"] = "Документ";
$MESS["WZD_OPTION_1"] = "*Документ";
$MESS["WZD_OPTION_2"] = "ID";
$MESS["WZD_OPTION_3"] = "*ID";
$MESS["WZD_OPTION_4"] = "Активность";
$MESS["WZD_OPTION_5"] = "*Активность";
$MESS["WZD_OPTION_6"] = "Сортировка";
$MESS["WZD_OPTION_7"] = "*Сортировка";
$MESS["WZD_OPTION_8"] = "*Название";
$MESS["WZD_OPTION_9"] = "**Название";
$MESS["WZD_OPTION_10"] = "Описание";
$MESS["WZD_OPTION_11"] = "*Описание";
$MESS["WZD_OPTION_12"] = "Разделы";
$MESS["WZD_OPTION_13"] = "*Разделы";
$MESS["WZD_OPTION_14"] = "";
$MESS["WZD_OPTION_15"] = "*";
?>
