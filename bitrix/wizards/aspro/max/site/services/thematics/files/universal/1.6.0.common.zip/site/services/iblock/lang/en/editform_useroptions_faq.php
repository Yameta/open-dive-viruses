<?
$MESS["WZD_OPTION_0"] = "Вопрос";
$MESS["WZD_OPTION_1"] = "*Вопрос";
$MESS["WZD_OPTION_2"] = "ID";
$MESS["WZD_OPTION_3"] = "*ID";
$MESS["WZD_OPTION_4"] = "Активность";
$MESS["WZD_OPTION_5"] = "*Активность";
$MESS["WZD_OPTION_6"] = "*Название";
$MESS["WZD_OPTION_7"] = "**Название";
$MESS["WZD_OPTION_8"] = "*Внешний код";
$MESS["WZD_OPTION_9"] = "**Внешний код";
$MESS["WZD_OPTION_10"] = "Сортировка";
$MESS["WZD_OPTION_11"] = "*Сортировка";
$MESS["WZD_OPTION_12"] = "Значения свойств";
$MESS["WZD_OPTION_13"] = "*Значения свойств";
$MESS["WZD_OPTION_14"] = "Название кнопки";
$MESS["WZD_OPTION_15"] = "*Название кнопки";
$MESS["WZD_OPTION_16"] = "Ссылка для кнопки";
$MESS["WZD_OPTION_17"] = "*Ссылка для кнопки";
$MESS["WZD_OPTION_18"] = "Анонс";
$MESS["WZD_OPTION_19"] = "*Анонс";
$MESS["WZD_OPTION_20"] = "Описание для анонса";
$MESS["WZD_OPTION_21"] = "*Описание для анонса";
$MESS["WZD_OPTION_22"] = "Разделы";
$MESS["WZD_OPTION_23"] = "*Разделы";
$MESS["WZD_OPTION_24"] = "";
$MESS["WZD_OPTION_25"] = "*";
?>
