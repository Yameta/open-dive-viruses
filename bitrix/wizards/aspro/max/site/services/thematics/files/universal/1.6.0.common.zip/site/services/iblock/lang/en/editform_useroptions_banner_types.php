<?
$MESS["WZD_OPTION_0"] = "";
$MESS["WZD_OPTION_1"] = "*";
?>
